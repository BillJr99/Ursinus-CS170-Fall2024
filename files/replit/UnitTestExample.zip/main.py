def whatever(x):
  return x * 2

def main():
  print(whatever(2))

if __name__ == "__main__":
  main()
  