import main
import unittest

class TestMain(unittest.TestCase):
  def test_whatever(self):
    self.assertEqual(main.whatever(6), 12)

if __name__ == "__main__":
  unittest.main()
