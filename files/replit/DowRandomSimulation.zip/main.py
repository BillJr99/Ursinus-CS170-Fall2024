from random import uniform
import matplotlib.pyplot as plt

dow = 29296
dowvals = []

for year in range(30):
  print("Happy New Year!")

  for day in range(365):
    rnd = uniform(-3, 3)
    dow = dow + rnd
    dowvals.append(dow)
    print(dow)

plt.plot(dowvals)
plt.show()
