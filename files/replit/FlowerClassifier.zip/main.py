# https://scikit-learn.org/stable/auto_examples/ensemble/plot_voting_decision_regions.html#sphx-glr-auto-examples-ensemble-plot-voting-decision-regions-py
# BSD license

import matplotlib.pyplot as plt

# pip install scikit-learn
from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier
from sklearn.inspection import DecisionBoundaryDisplay
import sklearn.metrics

# Loading some example data
iris = datasets.load_iris()
X = iris.data[:, [0, 2]] # take the first and third feature columns, which are the sepal length and petal length in cm ([0, 2]), and all rows (:)
y = iris.target # the "answer key" we will train on

# Print some attributes of the data
print(X)
print(iris.target_names)
print(iris.feature_names[0:3:2]) # another way to say the 0 and 2 indices of the list (from 0 to 3, counting by 2)

# Training decision tree classifier
# What four questions would you ask?
clf1 = DecisionTreeClassifier(max_depth=4)
clf1.fit(X, y)

# Plotting decision regions
# X[:, 0] means the first column of the X training set, and X[:, 1] means the second column - this ensures we only plot two things, which is convenient for your eyes to see in 2D
fig, ax = plt.subplots()
DecisionBoundaryDisplay.from_estimator(clf1, X, alpha=0.4, ax=ax, response_method="predict")
ax.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor="k")
ax.set_title("Decision Boundary (max depth 4)")
plt.xlabel("Sepal Length (cm)")
plt.ylabel("Petal Length (cm)")
plt.savefig("output.png")
plt.show()
plt.clf()

# Evaluate accuracy
preds = clf1.predict(X)
print(sklearn.metrics.accuracy_score(y, preds))

# Display the decision tree
fig = plt.figure(figsize=(25,20))
print(sklearn.tree.export_text(clf1))
sklearn.tree.plot_tree(clf1, feature_names=iris.feature_names, class_names=iris.target_names, filled=True)
fig.savefig("tree.png")
plt.show()

# Try your own predictions: for the targets, setosa is 0, versicolor is 1, virginica is 2; for the inputs, the first element is the sepal length, and the second is the petal length (and you can provide as many of these pairs as you want; you'll get one output answer per entry)
print(clf1.predict([[5, 1.4], [6, 5]]))

#Copyright (c) 2007-2022, scikit-learn developers, All rights reserved.

#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

#Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#All advertising materials mentioning features or use of this software must display the following acknowledgement: This product includes software developed by the scikit-learn developers.
#Neither the name of the scikit-learn developers nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#THIS SOFTWARE IS PROVIDED BY scikit-learn developers AS IS AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL scikit-learn developers BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.