from collections import Counter
import urllib.request

# Minimum word length to count (or None for all)
MINLEN = 6

# Number of federalist papers to read
NUMFEDS = 85

# https://stackoverflow.com/questions/22428842/how-to-normalize-a-counter-and-combine-2-normalized-counters-python
def normalize_counter(count):
  total = sum(count.values(), 0.0)
  for key in count:
    count[key] /= total
  return count
  
# https://www.geeksforgeeks.org/text-analysis-in-python-3/
def count_words_fast(text, word_counts=None, minlen=None):    
    text = text.lower()
    skips = [".", ", ", ":", ";", "'", '"', "-", "?", "!", "\r\n", "\r", "\n"]
  
    for ch in skips:
      text = text.replace(ch, " ")

    text = text.strip()

    input = text.split(" ")

    # remove small words
    if not (minlen is None):
      input = [x for x in input if len(x) >= minlen]

    if word_counts is None:
      word_counts = Counter(input)
    else:
      word_counts.update(input)

    return word_counts

def read_file(filename):
  with(open(filename, 'r')) as file:
    return file.read()

def read_web(url):
  page = urllib.request.urlopen(url)
  data = page.read()
  page.close()
  return data.decode("utf-8")

def get_federalist_paper(allfeds, fedno):
  data = ""
  author = ""

  startno = "FEDERALIST No. " + str(fedno)
  endno = "FEDERALIST No. " + str(fedno+1)
  
  start = allfeds.find(startno)
  end = allfeds.find(endno)

  # Paper not found?
  if start == -1:
    return data

  # Find the end of the paper, or the end marker of the last paper, or the end of the file
  if end == -1:
    end = allfeds.find("*** END OF THE PROJECT GUTENBERG EBOOK THE FEDERALIST PAPERS ***")
    if end == -1:
      end = len(allfeds)

  # Remove the starting number
  start = start + len("FEDERALIST No. " + str(fedno))

  data = allfeds[start:end]

  # Stop at the signature at the end ("PUBLIUS"), if present
  publiuslocation = data.find("PUBLIUS")
  if publiuslocation > -1:
    data = data[:publiuslocation]

  # Get correct author
  if "MADISON, with HAMILTON" in data:
    author = "MADISON, HAMILTON"
  elif "MADISON" in data:
    author = "MADISON"
  elif "HAMILTON" in data:
    author = "HAMILTON"
  elif "JAY" in data:
    author = "JAY"
    
  # Remove authors
  data = data.replace("MADISON", "").replace("JAY", "").replace("HAMILTON", "").replace("MADISON, with HAMILTON", "")

  data = data.strip() # remove leading/trailing whitespace
  
  return author, data

# Return an array of dictionaries representing federalist papers
# index i is paper i+1 (paper 1 is index 0)
# fields are author and text
def read_federalist_papers():
  allfeds = read_web("https://www.gutenberg.org/cache/epub/1404/pg1404.txt")
  feds = []
  for i in range(1, NUMFEDS+1):
    author, text = get_federalist_paper(allfeds, i)
    fed = {}
    fed['author'] = author
    fed['text'] = text
    feds.append(fed)
  return feds

# https://www.geeksforgeeks.org/python-convert-list-tuples-dictionary/
def tuples_to_dict(tup, di=None):
    if di is None:
      di = {}
      
    for a, b in tup:
        di.setdefault(a, []).append(b)
      
    return di

def flatten_dict(di):
  for key in di:
    di[key] = di[key][0]
  return di

def average_counter(count):
  sum = 0
  count = 0
  
  for key in count:
    count = count + 1
    sum = sum + count[key]

  avg = 0
  if count > 0:
    avg = sum / count

  return avg
  
def compute_score(textcount, corpuscount, words=100000):
  textcommon = textcount.most_common(words)
  corpuscommon = corpuscount.most_common(words)
  
  items, freqs = zip(*textcommon)
  corpusitems, corpusfreqs = zip(*corpuscommon)
  
  score = 0
  
  for i in range(len(items)):
    word = items[i]
        
    if word in corpusitems:
      corpusidx = corpusitems.index(word)
    else:
      corpusidx = words # max score
    
    diff = abs(i - corpusidx)

    score = score + diff

  # make higher scores represent better quality predictions by taking the inverse of the difference of the ranks
  return 1.0 / score 
  
def predict_author(feds, word_counts, fedno):
  predicted = ""
  text = feds[fedno-1]['text']
  actual = feds[fedno-1]['author']

  counts = count_words_fast(text, minlen=MINLEN)
  counts = normalize_counter(counts)

  scores = {}
  for author in ["JAY", "MADISON", "HAMILTON"]:
    score = compute_score(counts, word_counts[author])
    scores[author] = score
  
  # highest score wins
  predicted = max(scores, key=scores.get)
  
  return predicted, actual
  
def main():
  feds = read_federalist_papers()

  word_counts = {}
  word_counts["JAY"] = None
  word_counts["HAMILTON"] = None
  word_counts["MADISON"] = None
  word_counts["MADISON, HAMILTON"] = None
  
  for i in range(len(feds)):
    fed = feds[i]
    author = fed["author"]
    text = fed["text"]
    
    word_counts[author] = count_words_fast(text, word_counts=word_counts[author], minlen=MINLEN)

  for author in word_counts:
    word_counts[author] = normalize_counter(word_counts[author])
  
  for i in range(len(feds)):
    predicted, actual = predict_author(feds, word_counts, i+1)
    
    print("FEDERALIST No. {} was written by {}, and I predicted {}".format(str(i+1), actual, predicted))
  
if __name__ == "__main__":
  main()