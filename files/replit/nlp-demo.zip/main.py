import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import spacy
from spacy.tokens import DocBin
import random
import os

# Function to convert the data to spaCy's binary format 
def create_docbin(dataset, output_name):
    # Creating a blank spacy pipeline to serve as a tokenizer
    nlp = spacy.blank('en')
    # Creating a DocBin object to hold spaCy documents
    doc_bin = DocBin()
    # Converting each tuple into a spaCy Doc object
    for doc, label in nlp.pipe(dataset, as_tuples=True):
        doc.cats = {'positive': label, 'negative': 1 - label} # Setting the document's category to be its label
        doc_bin.add(doc) # Adding the Doc to the DocBin
    
    # Writing the DocBin object to a file 
    doc_bin.to_disk(f"./{output_name}.spacy")
    print(f"{output_name} set contains {len(doc_bin)} documents")

    return doc_bin
  
# Reading in the data into a pandas dataframe object
# Kaggle dataset available at https://github.com/azucker99/NLPDemo/blob/main/fake_job_postings.csv
df = pd.read_csv("fake_job_postings.csv")

# Exploratory Data Analysis
print(f"Number of rows {df.shape[0]} \nNumber of columns: {df.shape[1]}")
df.head()

# Checking for missing values
df.isnull().sum()

# Visualizing the first company profile 
df.loc[0].company_profile

# Visualizing how many job postings are actually fraudulent 
fraudulent_series = df.fraudulent.apply(lambda x: 'fraudulent' if x else 'not_fraudulent')
fraudulent_series.value_counts(sort=True).plot(kind='barh')
plt.xlabel('Count')
plt.ylabel('Fraudulent');
print(fraudulent_series.value_counts())

# Our training data will come from the description column
df2 = df[['description','fraudulent']].dropna() # Condenses the dataframe to the two columns and drops null values
print(df2.shape)
df2.head()

# Converting the data from a dataframe to the appropriate training format

# Adds a tuples column for each description and its label
df2['tuples'] = df2.apply(lambda row: (row['description'], row['fraudulent']), axis = 1)
# Converts that column to a list
data = df2['tuples'].to_list()
# Printing out the first two entries of our formatted dataset 
data[:2]

# Splitting data into training and testing data 
train_size = 0.8 # Data will consist of 80% of the training set 
split = int(len(data)*train_size) # The number of documents that will be in the training set

# Setting seed for reproducibility
random.seed(42)
random.shuffle(data) # Shuffling the data so the model does not learn from the order

# Setting train and test set by indexing data to be before and after split 
train = data[:split]
test = data[split:]

# Creates the training and test files
train_docbin = create_docbin(train, 'train')
test_docbin = create_docbin(test, 'test')

# Creating the configuration file for model training
os.system("python -m spacy init config config.cfg --lang en --pipeline textcat --optimize efficiency --force")

# Training the model
# Max epochs set to 1 epoch for training brevity
# To complete training, remove "--training.max_epochs 1" from command
os.system("python -m spacy train config.cfg --output ./output --paths.train ./train.spacy --paths.dev ./test.spacy --training.max_epochs 1")

# Evaluating the model using common classification metrics (precision, recall, F1 score)
os.system("python -m spacy evaluate output/model-best test.spacy --output metrics.json")