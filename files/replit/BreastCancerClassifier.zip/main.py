# https://www.digitalocean.com/community/tutorials/how-to-build-a-machine-learning-classifier-in-python-with-scikit-learn
# CC Attribution-NonCommercial-ShareAlike 4.0 International License
# https://creativecommons.org/licenses/by-nc-sa/4.0/

import matplotlib.pyplot as plt

# pip install scikit-learn
import sklearn 
import sklearn.datasets
import sklearn.model_selection
import sklearn.naive_bayes 
import sklearn.metrics
import sklearn.inspection

data = sklearn.datasets.load_breast_cancer()

# Organize our data
label_names = data['target_names']
labels = data['target']
feature_names = data['feature_names']
features = data['data']

# Look at our data
print(label_names)
print(labels)
print(feature_names)
print(features)

# Split our data
train, test, train_labels, test_labels = sklearn.model_selection.train_test_split(features, labels,test_size=0.33,random_state=42)

# Initialize our classifier
gnb = sklearn.naive_bayes.GaussianNB()

# Train our classifier
gnb.fit(train, train_labels)

# Make predictions
preds = gnb.predict(test)
print(preds)

# Evaluate accuracy
print(sklearn.metrics.accuracy_score(test_labels, preds))

# Visualize the results
# There are 30 features, but we will visualize in 2 dimensions by choosing the first two ([:, 0] and [:, 1]), which are the radius and texture
malignant = test[test_labels==0] # select those rows from test where the label is 0 for malignant
benign = test[test_labels==1] # and same for benign
fig, ax = plt.subplots()
ax.scatter(malignant[:, 0], malignant[:, 1], color='r', label="Malignant Tumors")
ax.scatter(benign[:, 0], benign[:, 1], color='b', label="Benign Tumors")
plt.title("Tumor Classification")
plt.xlabel("Mean Radius")
plt.ylabel("Mean Texture")
plt.legend()
plt.savefig("output.png")
plt.show()