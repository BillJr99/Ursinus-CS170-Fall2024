# http://www.ezgraphics.org/UserGuide/GettingStarted
# In shell: wget http://www.ezgraphics.org/uploads/Software/Download/ezgraphics-2.2.tar.gz && pip install ezgraphics-2.2.tar.gz

from ezgraphics import GraphicsWindow
import random

win = GraphicsWindow(640, 480)
win.setTitle("My First Drawing")

i = 0
j = 0
lasti = -1
lastj = -1

canvas = win.canvas()

canvas.setFill(0,0,0)
canvas.drawRectangle(0, 0, 640, 480)

while True:
  if i > 0 and j > 0:
    canvas.setFill(0,0,0)
    canvas.drawRectangle(i-1, j-1, 10, 20)
    
  canvas.setFill(255, 255, 255)
  canvas.drawRectangle(i, j, 10, 20)

  lasti = i
  lastj = j
  
  i = i + random.randint(-1, 1)
  j = j + random.randint(-1, 1)

  if i > 640:
    i = 639
  if j > 480:
    j = 479

  if i < 0:
    i = 1
  if j < 0:
    j = 1

  win.pause(1)
  
win.wait()