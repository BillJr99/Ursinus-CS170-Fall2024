# http://www.ezgraphics.org/UserGuide/GettingStarted
# In shell: wget http://www.ezgraphics.org/uploads/Software/Download/ezgraphics-2.2.tar.gz && pip install ezgraphics-2.2.tar.gz

from ezgraphics import GraphicsWindow

win = GraphicsWindow(640, 480)
win.setTitle("My First Drawing")

canvas = win.canvas()

canvas.setFill(255, 0, 0)
canvas.drawRectangle(40, 40, 100, 200)

canvas.setFill(255, 255, 255)
canvas.setOutline(0, 255, 0)
canvas.drawRectangle(200, 200, 150, 50)

win.wait()