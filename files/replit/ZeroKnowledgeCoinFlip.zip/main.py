import sys
import hashlib

print("Are you the sender or receiver?  Enter 0 for sender, 1 for receiver.")
player = input()
player = int(player)

sender = False

if player == 0:
  sender = True
elif player == 1:
  sender = False
else:
  print("Invalid player number")
  sys.exit(-1)

# Sender sends a random string
# Flipper encrypts coin toss result plus random string with private key, hashes, and sends
# Sender sends guess
# Flipper sends non-hashes encryption.  Sender can decrypt with Public key to see result and compare encrypted version with hash to verify

rnd_string = ''
hashed = ''
guess = ''
unhashed = ''

if sender:
  print("Ask the receiver to enter a random string to incorporate into their message.")
else:
  print("Input the random string you've been asked to include")
  rnd_string = input()
  
  heads_or_tails = -1
  while heads_or_tails < 0 or heads_or_tails > 1:
    print("Enter 0 for heads, 1 for tails")
    heads_or_tails = int(input())
  
  unhashed = str(heads_or_tails) + '-' + rnd_string
  hashed = hashlib.sha256(unhashed.encode("utf-8")).hexdigest()

  print("The hashed message is: " + hashed)

if sender:
  print("Input the hashed message")
  hashed = input()
  
  heads_or_tails = -1
  while heads_or_tails < 0 or heads_or_tails > 1:
    print("Enter 0 for heads, 1 for tails")
    heads_or_tails = int(input())  

  print("Provide the heads or tails guess: " + str(heads_or_tails))
else:
  print("What was their guess?")
  guess = int(input())

  print(guess)

  print("Now tell them the unhashed message: " + unhashed)

if sender:
  print("What was the unhashed message?")
  unhashed = input()
  
  hashed = hashlib.sha256(unhashed.encode("utf-8")).hexdigest()
  print("The hashed version should match, and the first character should be the coin toss result: " + hashed)
  