# https://realpython.com/logistic-regression-python/

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
import matplotlib.pyplot as plt


# https://scikit-learn.org/stable/auto_examples/linear_model/plot_logistic.html
# https://stackoverflow.com/questions/46085762/sklearn-logistic-regression-plotting-probability-curve-graph
# Assumes 1D model
def logistic_sigmoid(X, y, clf, x_range=100):
  Xs = [i for i in range(x_range)]
  Ys = [clf.predict_proba([[value]])[0][1] for value in range(x_range)]

  plt.scatter(X, y)
  plt.plot(Xs, Ys, color='red')
  plt.savefig("Sigmoid")
  plt.show()


# plot sklearn.linear_model LogisticRegression
def roc(X_test, y_test, model):
  logit_roc_auc = roc_auc_score(y_test, model.predict(X_test))
  fpr, tpr, thresholds = roc_curve(y_test, model.predict_proba(X_test)[:, 1])
  plt.figure()
  plt.plot(fpr,
           tpr,
           label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
  plt.plot([0, 1], [0, 1], 'r--')
  plt.xlim([0.0, 1.0])
  plt.ylim([0.0, 1.05])
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Receiver operating characteristic')
  plt.legend(loc="lower right")
  plt.savefig('Log_ROC')
  plt.show()


def model_results(clf, x, y):
  p_pred = clf.predict_proba(x)
  y_pred = clf.predict(x)
  score_ = clf.score(x, y)
  conf_m = confusion_matrix(y, y_pred)
  report = classification_report(y, y_pred)

  return p_pred, y_pred, score_, conf_m, report


################################################################

data = [[8, 1], [2, 0], [1, 0], [6, 1], [7, 1], [3, 0], [3, 1], [5, 0]]
y = [row[1] for row in data]  # last column contains Y values
x = [row[0] for row in data]  # remove last column from input data
x = np.array(x).reshape(-1, 1)

clf = LogisticRegression(solver='liblinear', C=10.0, random_state=0)
clf.fit(x, y)

p_pred, y_pred, score_, conf_m, report = model_results(clf, x, y)

print("Training Performance:")
print(report)
print(conf_m)

################################################################

testing = [[7, 1], [3, 0], [2, 0], [5, 1], [8, 1], [1, 0]]
y = [row[1] for row in data]  # last column contains Y values
x = [row[0] for row in data]  # remove last column from input data
x = np.array(x).reshape(-1, 1)

p_pred, y_pred, score_, conf_m, report = model_results(clf, x, y)

for i in range(len(y_pred)):
  print("Prediction on {}: {} ({} probability); correct answer {}".format(
    x[i], y_pred[i], p_pred[i], y[i]))

print("Testing Performance:")
print(report)
print(conf_m)

roc(x, y, clf)
logistic_sigmoid(x, y, clf, x_range=10)
