import rsamath
import sys

def genkey(a, b):
    c = a * b
    m = (a - 1) * (b - 1) # rsamath.totient(c), but too expensive in practice!
    e = rsamath.coprime(m)
    d = rsamath.mod_inverse(e, m)

    return e, d, c, m
  
def main():
    if len(sys.argv) < 2:
        print("nth prime, mth prime")
        sys.exit(-1)      
           
    n1 = int(sys.argv[1])
    n2 = int(sys.argv[2])
        
    a = rsamath.getNthPrime(n1)
    b = rsamath.getNthPrime(n2)
        
    e,d,c,m = genkey(a,b)

    print("Public Key: (E={}, C={}), Private Key: (D={}, C={})".format(e, c, d, c))

    if rsamath.validate_keys(e, d, c, m):
      print("Keys are valid")
    else:
      print("WARNING: Keys are not valid")
  
if __name__ == '__main__':
    main()  