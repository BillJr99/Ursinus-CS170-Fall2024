import sys
import rsamath

def main():
    if len(sys.argv) < 3:
        print("private_key c encrypted_character (one character at a time!)")
        sys.exit(-1)
      
    key = int(sys.argv[1])
    c = int(sys.argv[2])
    enc_char = int(sys.argv[3])
    
    decrypted_char = rsamath.endecrypt(enc_char, key, c)
    decrypted = chr(decrypted_char)
    print(decrypted)

if __name__ == '__main__':
    main()  