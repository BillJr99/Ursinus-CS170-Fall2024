import sys
import rsamath

def main():
    if len(sys.argv) < 3:
        print("public_key c string")
        sys.exit(-1)
      
    key = int(sys.argv[1])
    c = int(sys.argv[2])
    entry = sys.argv[3]
    
    i = 0
    while i < len(entry):
        enterchar = ord(entry[i])
        mutate = rsamath.endecrypt(enterchar, key, c)
      
        print(str(mutate))
        i += 1  

if __name__ == '__main__':
    main()  