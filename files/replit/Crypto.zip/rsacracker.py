import sys
import rsamath

def main():
    if len(sys.argv) < 2:
        print("public_key c")
        sys.exit(-1)

    e = int(sys.argv[1])
    c = int(sys.argv[2])

    # We need m = rsamath.totient(c) but should be too expensive to do in practice!
    # Alternatively, we could find a and b, the factors of c, but this requires equivalent computational effort!
    m = rsamath.totient(c)
    
    # compute d just like we computed d from e in the original RSA algorithm
    d = rsamath.mod_inverse(e, m)
    
    print("Their private key was found to be (D={}, C={})".format(d, c))

if __name__ == '__main__':
    main()
