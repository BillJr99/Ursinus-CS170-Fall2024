import sys
import random

def getNthPrime(n):
    k = 0
    p = 2
    while k < n:
        p += 1
        if isprime(p):
            k += 1
    return p

def isprime(p):
    i = 2
    while i < p:
        if (p % i == 0):
            return False
        i += 1
    return True

#math.gcd()
def GCD(a, b):
    if (b == 0):
        return a
    return GCD(b, a % b)

def modulo(a, b, c):
  return (a**b) % c

# from sympy.ntheory.factor_ import totient
def totient(n):
    count = 0
    
    i = 1
    while i < n:
        if (GCD(n, i) == 1):
            count += 1
        i += 1
    return count

def coprimes(x, maxcandidates=30, lowerbound=-1, upperbound=-1):
  candidates = []

  if lowerbound == -1:
    lowerbound = x+1

  if upperbound == -1:
    upperbound = 10*x
  
  while len(candidates) < maxcandidates and len(candidates) < sys.maxsize:
    candidate = random.randint(lowerbound, upperbound)
    if not (candidate in candidates) and GCD(x, candidate) == 1:
      candidates.append(candidate)
    else:
      lowerbound = lowerbound - 1
      upperbound = upperbound + 1
      
  return candidates
      
def coprime(x):
  candidates = coprimes(x)
  candidate = random.choice(candidates)
  return candidate

def mod_inverse(base, mod):
    tot = totient(mod) - 1
    inv = modulo(base, tot, mod)
    return inv

def endecrypt(x, key, mod):
  return modulo(x, key, mod)

def validate_keys(e, d, c, m):
  valid = True

  if (e*d) % m != 1:
    valid = False

  if GCD(e, c) != 1:
    valid = False

  if GCD(d, c) != 1:
    valid = False  

  if GCD(e, m) != 1:
    valid = False

  if GCD(d, m) != 1:
    valid = False
    
  return valid