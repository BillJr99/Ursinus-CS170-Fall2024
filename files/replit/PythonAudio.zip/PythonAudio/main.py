import sounds

# https://github.com/cleversonahum/dtmf-generator/blob/main/dtmf-generator.py
DTMF_TABLE = {
    "1": [1209, 697],
    "2": [1336, 697],
    "3": [1477, 697],
    "A": [1633, 697],
    "4": [1209, 770],
    "5": [1336, 770],
    "6": [1477, 770],
    "B": [1633, 770],
    "7": [1209, 852],
    "8": [1336, 852],
    "9": [1477, 852],
    "C": [1633, 852],
    "*": [1209, 941],
    "0": [1336, 941],
    "#": [1477, 941],
    "D": [1633, 941],
    "dial_tone": [350, 440]
}

#sounds.sine_tone(2000, 0.5, volume=0.25)
#sounds.square_tone(2000, 0.25, volume=0.25)

sounds.dtmf_tone(*DTMF_TABLE['dial_tone'], 2, volume=0.25) # dial tone: 350, 400
sounds.dtmf_tone(*DTMF_TABLE['6'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['1'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['0'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['4'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['0'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['9'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['3'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['2'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['6'], 0.25, volume=0.25)
sounds.dtmf_tone(*DTMF_TABLE['8'], 0.25, volume=0.25)

C = 261.63
E = 329.63
G = 392
sounds.sine_chord([C, E, G], 1, volume=0.25)