def numSyllables(s):
  return sum(list(map(lambda x: 1 if x in ["a","i","e","o","u","y","A","E","I","O","U","y"] else 0,s)))

def numWords(s):
  return len(s.split(" "))

def numSentences(s):
  return sum(list(map(lambda x: 1 if x in [".", "!", "?"] else 0,s)))

def numWordsPerSentence(s):
  if numSentences(s) == 0:
    return 0
  else:
    return numWords(s) / numSentences(s)

def numSyllablesPerWord(s):
  if numWords(s) == 0:
    return 0
    
  syllables = 0
  for word in s.split(" "):
    syllables += numSyllables(word)

  return syllables / numWords(s)

def flesch_kincaid(s):
  return 0.39 * numWordsPerSentence(s) + 11.8 * numSyllablesPerWord(s) - 15.59

def main():
  s = input("Please enter your text:")
  gradelevel = flesch_kincaid(s)
  print(gradelevel)

if __name__ == "__main__":
  main()