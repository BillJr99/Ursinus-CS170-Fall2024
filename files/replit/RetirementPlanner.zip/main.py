from random import uniform

num_years = 30
annual_spend = 30000
daily_market_fluctuation = 0.01
num_trials = 100
successes = 0

for trial in range(num_trials):
  investment_balance = 1000000

  for year in range(num_years):
    print("Happy New Year: {}!".format(year))

    # Spend all your money on the first day of the year (yolo!)
    investment_balance = investment_balance - annual_spend

    for day in range(365):  # we'll assume 365 days in each year
      market_change_percentage = uniform(-daily_market_fluctuation, daily_market_fluctuation)

      # Could be positive or negative
      daily_change = investment_balance * market_change_percentage

      investment_balance = investment_balance + daily_change

      #print(investment_balance)

  if investment_balance > 0:
    print("You made it!  You still have ${0:,.2f} left over.".format(investment_balance))
    successes = successes + 1
  else:
    print("Uh oh, better save some $$$.  You overspent by ${0:,.2f}".format(investment_balance))

success_percentage = successes / num_trials
print("You were successful {0:,.2f}% of the time".format(success_percentage * 100))
