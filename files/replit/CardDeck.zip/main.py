for i in range(4):
  for j in range(1, 15):
    if i == 0:
      suit = "Club"
    elif i == 1:
      suit = "Spade"
    elif i == 2:
      suit = "Diamond"
    elif i == 3:
      suit = "Heart"

    if j == 11:
      card = "J"
    elif j == 12:
      card = "Q"
    elif j == 13:
      card = "K"
    elif j == 14:
      card = "A"
    else:
      card = j

    print("{} of {}".format(card, suit))