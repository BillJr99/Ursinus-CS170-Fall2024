from random import random

num_trials = 10000000

successes = 0

for i in range(num_trials):
  x = random()
  y = random()

  if x**2 + y**2 < 1:
    successes = successes + 1

print(4 * (successes / num_trials))