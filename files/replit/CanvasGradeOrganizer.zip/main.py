grades = {}

f = open("grades.txt")
for line in f:
  #print(line)

  parts = line.split(",")

  #print(parts)

  course = parts[0]
  title = parts[1]
  grade = parts[2]

  #print(grade)

  if not (course in grades):
    grades[course] = []

  grades[course].append(float(grade))

print(grades)

for course in grades:
  print("In {} I got these grades: {}.  There are {} grades.".format(course, grades[course], len(grades[course])))

  sum = 0

  # start a for loop over all the elements in grades[course]
    # add them together sum = sum + ...
  # after the loop, divide by len(grades[course])