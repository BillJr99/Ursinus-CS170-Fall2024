import sys

def main():
  if len(sys.argv) < 2:
    ccnum = input("Enter credit card number: ")
  else:
    ccnum = sys.argv[1]  

  checkdigit = int(ccnum[-1])

  # calculate all digits except the last one
  sum = 0
  for i in range(len(ccnum)-1):
    if i % 2 == 1: # double every other digit, starting with position 1 (the odds)
      val = int(ccnum[i]) * 2
    else:
      val = int(ccnum[i])

    # loop over each digit and add them together; so 12 should be 1+2
    valstr = str(val)
    for j in range(len(valstr)):
      print("Adding " + valstr[j])
      sum = sum + int(valstr[j])

  # the last digit should be this sum mod 10
  check10 = sum % 10

  if check10 == checkdigit:
    print("The check digit {} matches!".format(check10))
  else:
    print("The check digit was {}, and should have been {}".format(check10, checkdigit))
      
if __name__ == "__main__":
  main()