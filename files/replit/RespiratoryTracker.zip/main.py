import csv
import numpy as np

SAMPLE_RATE = 10 # each X is worth 0.1 seconds

def find_next_slope_change(y, idx):
  result = 0
  
  for i in range(idx+2, len(y)):
    s1 = y[i-1] - y[i-2]
    s2 = y[i] - y[i-1]

    #print("{} {} {} {} {} {}".format(y[i], y[i-1], y[i-2], s1, s2, i))
    
    if np.sign(s2) != np.sign(s1):
      result = i - 1
      break

  return result
  
f = open('respiratorygenerator.csv')
csvfile = csv.reader(f)

t = []
y = []
rownum = 0
for row in csvfile:
  if rownum > 0: # skip header
    t.append(float(row[0]))
    y.append(float(row[1]))
    
  rownum = rownum + 1

#print(t)
#print(y)

lastchange = -1
currentchange = 0

i = 0
while i < len(y):
  currentchange = find_next_slope_change(y, i)
  
  delta = currentchange - lastchange

  if delta > 0 and lastchange > -1:
    print("Change between {} and {} at {}".format(lastchange, currentchange, delta))

    bpm = SAMPLE_RATE * (60 / (delta * 2)) # twice delta because it is peak to trough not peak to peak

    print("BPM: {}".format(bpm))
    
  lastchange = currentchange

  i = max(currentchange + 1, i + 1)